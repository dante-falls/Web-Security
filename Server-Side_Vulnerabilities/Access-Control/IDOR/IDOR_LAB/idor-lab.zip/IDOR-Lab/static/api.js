// api.js

async function apiRequest(method, endpoint, body=null) {
    const options = {
        method: method,
        headers: {
            "Content-Type": "application/json"
        }
    };

    if (body !== null) {
        options.body = JSON.stringify(body);
    }

    const res = await fetch(endpoint, options);
    return await res.json();
}

// ==========================
// AUTH
// ==========================

async function login(username, password) {
    return await apiRequest("POST", "/api/auth/login", { username, password });
}

async function logout() {
    return await apiRequest("POST", "/api/auth/logout", {});
}

async function getMe() {
    return await apiRequest("GET", "/api/auth/me");
}

// ==========================
// POSTS
// ==========================

async function createPost(title, body) {
    return await apiRequest("POST", "/api/posts/create", { title, body });
}

async function listPosts() {
    return await apiRequest("GET", "/api/posts/list");
}

async function getPost(postId) {
    return await apiRequest("GET", `/api/posts/get?postId=${encodeURIComponent(postId)}`);
}

async function updatePost(postId, title, body) {
    return await apiRequest("POST", "/api/posts/update", { postId, title, body });
}

// ==========================
// COMMENTS
// ==========================

async function createComment(postId, content) {
    return await apiRequest("POST", "/api/comments/create", { postId, content });
}

async function listComments(postId) {
    return await apiRequest("GET", `/api/comments/list?postId=${encodeURIComponent(postId)}`);
}

async function updateComment(commentId, content) {
    return await apiRequest("POST", "/api/comments/update", { commentId, content });
}

async function deleteComment(commentId) {
    return await apiRequest("POST", "/api/comments/delete", { commentId });
}

// ==========================
// FRIENDS / BLOCK
// ==========================

async function addFriend(targetUserId) {
    return await apiRequest("POST", "/api/users/add-friend", { targetUserId });
}

async function blockUser(targetUserId) {
    return await apiRequest("POST", "/api/users/block", { targetUserId });
}

// ==========================
// PRIVATE MESSAGES
// ==========================

async function sendMessage(toUserId, content) {
    return await apiRequest("POST", "/api/messages/send", { toUserId, content });
}

async function inbox() {
    return await apiRequest("GET", "/api/messages/inbox");
}

// ==========================
// SETTINGS (BACKUP EMAIL)
// ==========================

async function addBackupEmail(email) {
    return await apiRequest("POST", "/api/settings/add-backup-email", { email });
}

async function listBackupEmails() {
    return await apiRequest("GET", "/api/settings/list-backup-emails");
}

async function deleteBackupEmail(backupEmailId) {
    return await apiRequest("POST", "/api/settings/delete-backup-email", { backupEmailId });
}

/*
    ----------------------------------------------------------
    Developer Note:

    We really need to get rid of this...
    ----------------------------------------------------------
*/

async function legacyRecentMessages(userId) {
    return await apiRequest(
        "GET",
        `/api/always-read-javascript-files/recentMessages?userId=${encodeURIComponent(userId)}`
    );
}
