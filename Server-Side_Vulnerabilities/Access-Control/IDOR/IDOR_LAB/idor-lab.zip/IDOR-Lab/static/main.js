async function doLogin() {
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;

    const res = await login(username, password);

    if (res.error) {
        alert(res.error);
        return;
    }

    window.location = "/dashboard";
}

async function loadDashboard() {
    const me = await getMe();
    if (me.error) {
        window.location = "/login";
        return;
    }

    document.getElementById("meBox").innerText =
        `Logged in as: ${me.username}`;

    const posts = await listPosts();
    const postList = document.getElementById("postList");
    postList.innerHTML = "";

    posts.posts.forEach(p => {
        const div = document.createElement("div");
        div.className = "postItem";
        div.innerHTML = `
            <h3>${p.title}</h3>
            <p>${p.body}</p>
            <a href="/post/${p.postId}">View Post</a>
            <hr>
        `;
        postList.appendChild(div);
    });
}

async function createNewPost() {
    const title = document.getElementById("newTitle").value;
    const body = document.getElementById("newBody").value;

    const res = await createPost(title, body);

    if (res.error) {
        alert(res.error);
        return;
    }

    alert("Post created!");
    await loadDashboard();
}

async function doLogout() {
    await logout();
    window.location = "/login";
}
