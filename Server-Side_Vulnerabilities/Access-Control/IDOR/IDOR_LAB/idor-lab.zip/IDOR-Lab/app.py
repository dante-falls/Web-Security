from flask import Flask, request, jsonify, make_response, redirect, render_template
import uuid
import time

app = Flask(__name__)

# =========================
# HARD CODED USERS
# =========================

USERS = {
    "user-a": {
        "password": "Password1!",
        "userId": "30bff3b0-c9c9-4383-9654-66ffc96f9685",
        "friends": set(),
        "blocked": set(),
        "backupEmails": {},  # backupEmailId -> email
    },
    "user-b": {
        "password": "Password2!",
        "userId": "bf45a935-e577-450f-8b38-52994f0c9ed9",
        "friends": set(),
        "blocked": set(),
        "backupEmails": {},
    },
    "user-c": {
        "password": "Password3!",
        "userId": "6f3f2ac2-8cb1-4ba2-9b89-c1779486e482",
        "friends": set(),
        "blocked": set(),
        "backupEmails": {},
    }
}

USERID_TO_USERNAME = {v["userId"]: k for k, v in USERS.items()}

# =========================
# IN-MEMORY DATABASE
# =========================

SESSIONS = {}   # sessionId -> { username, userId, createdAt }

POSTS = {}      # postId -> { postId, ownerUserId, title, body, createdAt, updatedAt }
COMMENTS = {}   # commentId -> { commentId, postId, ownerUserId, content, createdAt, updatedAt }
MESSAGES = {}   # messageId -> { messageId, fromUserId, toUserId, content, createdAt }

# UUID collision prevention registry
UUID_REGISTRY = set()

# Register fixed user UUIDs
for u in USERS.values():
    UUID_REGISTRY.add(u["userId"])


def generate_uuid():
    while True:
        new_id = str(uuid.uuid4())
        if new_id not in UUID_REGISTRY:
            UUID_REGISTRY.add(new_id)
            return new_id


def get_session():
    sid = request.cookies.get("sessionId")
    if not sid:
        return None
    return SESSIONS.get(sid)


def require_auth():
    sess = get_session()
    if not sess:
        return None, (jsonify({"error": "Unauthorized"}), 401)
    return sess, None


# =========================
# ROUTES (PAGES)
# =========================

@app.route("/")
def index():
    return redirect("/login")


@app.route("/login")
def login_page():
    return render_template("login.html")


@app.route("/dashboard")
def dashboard_page():
    return render_template("dashboard.html")


@app.route("/post/<postId>")
def post_page(postId):
    return render_template("post.html", postId=postId)


@app.route("/settings")
def settings_page():
    return render_template("settings.html")


@app.route("/messages")
def messages_page():
    return render_template("messages.html")


# =========================
# API AUTH
# =========================

@app.route("/api/auth/login", methods=["POST"])
def api_login():
    data = request.json or {}
    username = data.get("username", "")
    password = data.get("password", "")

    if username not in USERS:
        return jsonify({"error": "Invalid credentials"}), 403

    if USERS[username]["password"] != password:
        return jsonify({"error": "Invalid credentials"}), 403

    sessionId = generate_uuid()
    userId = USERS[username]["userId"]

    SESSIONS[sessionId] = {
        "sessionId": sessionId,
        "username": username,
        "userId": userId,
        "createdAt": int(time.time())
    }

    resp = make_response(jsonify({
        "message": "Login successful",
        "sessionId": sessionId,
        "userId": userId,
        "username": username
    }))

    resp.set_cookie("sessionId", sessionId, httponly=False)
    return resp


@app.route("/api/auth/me", methods=["GET"])
def api_me():
    sess, err = require_auth()
    if err:
        return err

    user = USERS[sess["username"]]

    # IMPORTANT: We still return userId in API responses for testing,
    # but UI will not display it.
    return jsonify({
        "username": sess["username"],
        "userId": sess["userId"],
        "friends": list(user["friends"]),
        "blocked": list(user["blocked"]),
        "backupEmails": user["backupEmails"]
    })


@app.route("/api/auth/logout", methods=["POST"])
def api_logout():
    sess = get_session()
    if sess:
        SESSIONS.pop(sess["sessionId"], None)

    resp = make_response(jsonify({"message": "Logged out"}))
    resp.delete_cookie("sessionId")
    return resp


# =========================
# POSTS
# =========================

@app.route("/api/posts/create", methods=["POST"])
def api_create_post():
    sess, err = require_auth()
    if err:
        return err

    data = request.json or {}
    title = data.get("title", "").strip()
    body = data.get("body", "").strip()

    if not title or not body:
        return jsonify({"error": "Title and body required"}), 400

    postId = generate_uuid()

    POSTS[postId] = {
        "postId": postId,
        "ownerUserId": sess["userId"],
        "title": title,
        "body": body,
        "createdAt": int(time.time()),
        "updatedAt": int(time.time())
    }

    return jsonify({"message": "Post created", "post": POSTS[postId]})


@app.route("/api/posts/list", methods=["GET"])
def api_list_posts():
    sess, err = require_auth()
    if err:
        return err

    return jsonify({"posts": list(POSTS.values())})


@app.route("/api/posts/get", methods=["GET"])
def api_get_post():
    sess, err = require_auth()
    if err:
        return err

    postId = request.args.get("postId")
    if not postId or postId not in POSTS:
        return jsonify({"error": "Post not found"}), 404

    return jsonify({"post": POSTS[postId]})


@app.route("/api/posts/update", methods=["POST"])
def api_update_post():
    sess, err = require_auth()
    if err:
        return err

    data = request.json or {}
    postId = data.get("postId")
    title = data.get("title", "").strip()
    body = data.get("body", "").strip()

    if not postId or postId not in POSTS:
        return jsonify({"error": "Post not found"}), 404

    # Weak authorization (intentional lab weakness)
    POSTS[postId]["title"] = title
    POSTS[postId]["body"] = body
    POSTS[postId]["updatedAt"] = int(time.time())

    return jsonify({"message": "Post updated", "post": POSTS[postId]})


# =========================
# COMMENTS
# =========================

@app.route("/api/comments/create", methods=["POST"])
def api_create_comment():
    sess, err = require_auth()
    if err:
        return err

    data = request.json or {}
    postId = data.get("postId")
    content = data.get("content", "").strip()

    if not postId or postId not in POSTS:
        return jsonify({"error": "Post not found"}), 404

    if not content:
        return jsonify({"error": "Content required"}), 400

    commentId = generate_uuid()

    COMMENTS[commentId] = {
        "commentId": commentId,
        "postId": postId,
        "ownerUserId": sess["userId"],
        "content": content,
        "createdAt": int(time.time()),
        "updatedAt": int(time.time())
    }

    return jsonify({"message": "Comment created", "comment": COMMENTS[commentId]})


@app.route("/api/comments/list", methods=["GET"])
def api_list_comments():
    sess, err = require_auth()
    if err:
        return err

    postId = request.args.get("postId")
    if not postId:
        return jsonify({"error": "postId required"}), 400

    post_comments = [c for c in COMMENTS.values() if c["postId"] == postId]
    return jsonify({"comments": post_comments})


@app.route("/api/comments/update", methods=["POST"])
def api_update_comment():
    sess, err = require_auth()
    if err:
        return err

    data = request.json or {}
    commentId = data.get("commentId")
    content = data.get("content", "").strip()

    if not commentId or commentId not in COMMENTS:
        return jsonify({"error": "Comment not found"}), 404

    if COMMENTS[commentId]["ownerUserId"] != sess["userId"]:
        return jsonify({"error": "Forbidden"}), 403

    COMMENTS[commentId]["content"] = content
    COMMENTS[commentId]["updatedAt"] = int(time.time())

    return jsonify({"message": "Comment updated", "comment": COMMENTS[commentId]})


@app.route("/api/comments/delete", methods=["POST"])
def api_delete_comment():
    sess, err = require_auth()
    if err:
        return err

    data = request.json or {}
    commentId = data.get("commentId")

    if not commentId or commentId not in COMMENTS:
        return jsonify({"error": "Comment not found"}), 404

    # Weak authorization (intentional lab weakness)
    deleted = COMMENTS.pop(commentId)

    return jsonify({"message": "Comment deleted", "deleted": deleted})


# =========================
# FRIENDS / BLOCK
# =========================

@app.route("/api/users/add-friend", methods=["POST"])
def api_add_friend():
    sess, err = require_auth()
    if err:
        return err

    data = request.json or {}
    targetUserId = data.get("targetUserId")

    if not targetUserId or targetUserId not in USERID_TO_USERNAME:
        return jsonify({"error": "Target user not found"}), 404

    if targetUserId == sess["userId"]:
        return jsonify({"error": "Cannot friend yourself"}), 400

    username = sess["username"]
    targetUsername = USERID_TO_USERNAME[targetUserId]

    if targetUserId in USERS[username]["blocked"]:
        return jsonify({"error": "You blocked this user"}), 403

    if sess["userId"] in USERS[targetUsername]["blocked"]:
        return jsonify({"error": "You are blocked by this user"}), 403

    USERS[username]["friends"].add(targetUserId)
    return jsonify({"message": "Friend added"})


@app.route("/api/users/block", methods=["POST"])
def api_block_user():
    sess, err = require_auth()
    if err:
        return err

    data = request.json or {}
    targetUserId = data.get("targetUserId")

    if not targetUserId or targetUserId not in USERID_TO_USERNAME:
        return jsonify({"error": "Target user not found"}), 404

    if targetUserId == sess["userId"]:
        return jsonify({"error": "Cannot block yourself"}), 400

    username = sess["username"]

    USERS[username]["blocked"].add(targetUserId)

    if targetUserId in USERS[username]["friends"]:
        USERS[username]["friends"].remove(targetUserId)

    return jsonify({"message": "User blocked"})


# =========================
# PRIVATE MESSAGES
# =========================

@app.route("/api/messages/send", methods=["POST"])
def api_send_message():
    sess, err = require_auth()
    if err:
        return err

    data = request.json or {}
    toUserId = data.get("toUserId")
    content = data.get("content", "").strip()

    if not toUserId or toUserId not in USERID_TO_USERNAME:
        return jsonify({"error": "User not found"}), 404

    if not content:
        return jsonify({"error": "Message content required"}), 400

    senderUsername = sess["username"]
    recipientUsername = USERID_TO_USERNAME[toUserId]

    if toUserId in USERS[senderUsername]["blocked"]:
        return jsonify({"error": "You blocked this user"}), 403

    if sess["userId"] in USERS[recipientUsername]["blocked"]:
        return jsonify({"error": "You are blocked by this user"}), 403

    messageId = generate_uuid()

    MESSAGES[messageId] = {
        "messageId": messageId,
        "fromUserId": sess["userId"],
        "toUserId": toUserId,
        "content": content,
        "createdAt": int(time.time())
    }

    return jsonify({"message": "Message sent"})


@app.route("/api/messages/inbox", methods=["GET"])
def api_inbox():
    sess, err = require_auth()
    if err:
        return err

    userId = sess["userId"]

    inbox = [m for m in MESSAGES.values() if m["toUserId"] == userId]

    # Do NOT expose messageId in inbox response (more realistic UI behavior)
    sanitized = []
    for m in inbox:
        sanitized.append({
            "fromUserId": m["fromUserId"],
            "content": m["content"],
            "createdAt": m["createdAt"]
        })

    return jsonify({"messages": sanitized})


# =========================
# HIDDEN LEGACY REQUEST
# =========================

@app.route("/api/always-read-javascript-files/recentMessages", methods=["GET"])
def api_recent_messages_hidden():
    sess, err = require_auth()
    if err:
        return err

    targetUserId = request.args.get("userId")
    if not targetUserId:
        return jsonify({"error": "userId required"}), 400

    recent = [
        m for m in MESSAGES.values()
        if m["toUserId"] == targetUserId
    ]

    recent_sorted = sorted(recent, key=lambda x: x["createdAt"], reverse=True)[:5]

    return jsonify({"recentMessages": recent_sorted})


# =========================
# BACKUP EMAILS
# =========================

@app.route("/api/settings/add-backup-email", methods=["POST"])
def api_add_backup_email():
    sess, err = require_auth()
    if err:
        return err

    data = request.json or {}
    email = data.get("email", "").strip()

    if not email or "@" not in email:
        return jsonify({"error": "Valid email required"}), 400

    backupEmailId = generate_uuid()

    USERS[sess["username"]]["backupEmails"][backupEmailId] = email

    return jsonify({"message": "Backup email added"})


@app.route("/api/settings/list-backup-emails", methods=["GET"])
def api_list_backup_emails():
    sess, err = require_auth()
    if err:
        return err

    # Return full mapping for API testing, but UI will not show IDs
    return jsonify({"backupEmails": USERS[sess["username"]]["backupEmails"]})


@app.route("/api/settings/delete-backup-email", methods=["POST"])
def api_delete_backup_email():
    sess, err = require_auth()
    if err:
        return err

    data = request.json or {}
    backupEmailId = data.get("backupEmailId")

    if not backupEmailId:
        return jsonify({"error": "backupEmailId required"}), 400

    # Weak authorization (intentional lab weakness)
    for uname, udata in USERS.items():
        if backupEmailId in udata["backupEmails"]:
            udata["backupEmails"].pop(backupEmailId)
            return jsonify({"message": "Backup email deleted"})

    return jsonify({"error": "Backup email not found"}), 404


# =========================
# RUN SERVER
# =========================

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=8001, debug=True)
